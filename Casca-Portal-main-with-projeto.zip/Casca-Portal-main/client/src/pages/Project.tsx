import { useEffect, useMemo, useState } from "react";
import { Layout } from "@/components/Layout";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import heroImg from "@assets/generated_images/aerial_view_of_rio_da_casca_nature.png";

type ProjectSection = {
  id: string;
  title: string;
  content?: string[];
  bullets?: string[];
};

type IdentityItem = {
  title: string;
  caption?: string;
  image?: string;
};

type ProjectContent = {
  title: string;
  subtitle?: string;
  updated_at?: string;
  cta?: { label: string; href: string };
  sections: ProjectSection[];
  sources?: { title: string; url: string }[];
  identity_gallery?: {
    symbols?: IdentityItem[];
    logos?: IdentityItem[];
    mascotes?: IdentityItem[];
  };
};

const FALLBACK: ProjectContent = {
  title: "Aliança Rio da Casca Vivo",
  subtitle:
    "Patrimônio, natureza e renda local — um projeto de turismo sustentável e pesquisa aplicada.",
  sections: [],
};

function toHtml(s: string) {
  return s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
}

export function Project() {
  const [data, setData] = useState<ProjectContent>(FALLBACK);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let isMounted = true;
    fetch("/content/alianca-rio-da-casca-vivo.json")
      .then((r) => r.json())
      .then((json) => {
        if (!isMounted) return;
        setData(json);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
    return () => {
      isMounted = false;
    };
  }, []);

  const toc = useMemo(() => {
    return (data.sections || []).map((s) => ({ id: s.id, title: s.title }));
  }, [data.sections]);

  return (
    <Layout>
      <Hero
        image={heroImg}
        title={data.title}
        subtitle={data.subtitle || "Projeto territorial com foco em conservação e desenvolvimento."}
        size="default"
      />

      <Section>
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col gap-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <p className="text-muted-foreground">
                  {data.updated_at ? `Atualizado em ${data.updated_at}` : "Atualização contínua pela Aliança"}
                  {!loaded && " • carregando conteúdo…"}
                </p>
              </div>
              {data.cta?.href && (
                <Button asChild>
                  <a href={data.cta.href} aria-label={data.cta.label}>
                    {data.cta.label}
                  </a>
                </Button>
              )}
            </div>

            {toc.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Mapa rápido</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {toc.map((item) => (
                      <a
                        key={item.id}
                        href={`#${item.id}`}
                        className="px-3 py-1 rounded-full text-sm bg-muted hover:bg-muted/70 transition-colors"
                      >
                        {item.title}
                      </a>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </Section>

      {(data.sections || []).map((section) => (
        <Section key={section.id} id={section.id} background="default">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-serif font-bold text-primary mb-4">{section.title}</h2>

            {section.content?.map((p, idx) => (
              <p key={idx} className="text-muted-foreground leading-relaxed mb-3">
                {p}
              </p>
            ))}

            {section.bullets && section.bullets.length > 0 && (
              <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                {section.bullets.map((b, idx) => (
                  <li key={idx} dangerouslySetInnerHTML={{ __html: toHtml(b) }} />
                ))}
              </ul>
            )}
          </div>
        </Section>
      ))}

      <Section background="muted" id="identidade-visual">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-serif font-bold text-primary mb-4">Identidade visual</h2>
          <p className="text-muted-foreground mb-6">
            Variações de símbolo, logo e mascotes para uso em WhatsApp, documentos e sinalização. (As imagens finais podem ser
            substituídas a qualquer momento.)
          </p>

          <div className="grid gap-6">
            <IdentityGrid title="Símbolos" items={data.identity_gallery?.symbols} />
            <IdentityGrid title="Logos" items={data.identity_gallery?.logos} />
            <IdentityGrid title="Mascotes" items={data.identity_gallery?.mascotes} />
          </div>
        </div>
      </Section>

      {data.sources && data.sources.length > 0 && (
        <Section id="fontes">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-serif font-bold text-primary mb-4">Fontes</h2>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              {data.sources.map((s, idx) => (
                <li key={idx}>
                  <a className="underline hover:no-underline" href={s.url} target="_blank" rel="noreferrer">
                    {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </Section>
      )}
    </Layout>
  );
}

function IdentityGrid({ title, items }: { title: string; items?: IdentityItem[] }) {
  if (!items || items.length === 0) return null;

  return (
    <div>
      <h3 className="text-2xl font-serif font-bold text-primary mb-3">{title}</h3>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((it, idx) => (
          <Card key={idx} className="overflow-hidden">
            {it.image && (
              <div className="h-40 bg-muted">
                <img src={it.image} alt={it.title} className="w-full h-full object-cover" loading="lazy" />
              </div>
            )}
            <CardHeader>
              <CardTitle className="text-lg">{it.title}</CardTitle>
            </CardHeader>
            {it.caption && (
              <CardContent>
                <p className="text-sm text-muted-foreground">{it.caption}</p>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
